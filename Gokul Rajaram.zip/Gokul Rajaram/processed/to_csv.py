import json
import pandas as pd

# -------- PATHS --------
JSON_FILE = "filtered_posts_cleaned.json"
CSV_FILE = "filtered_posts_cleaned.csv"

# -------- LOAD JSON --------
with open(JSON_FILE, "r", encoding="utf-8") as f:
    data = json.load(f)

# -------- CONVERT TO CSV --------
df = pd.DataFrame(data)
df.to_csv(CSV_FILE, index=False, encoding="utf-8-sig")

print(f"✅ Converted JSON to CSV: {CSV_FILE}")
