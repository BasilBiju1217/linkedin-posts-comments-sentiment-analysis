import json
import pandas as pd
from pathlib import Path

# --------------------------------------------------
# Paths (script runs inside: Gokul Rajaram/processed)
# --------------------------------------------------
CURRENT_DIR = Path(__file__).resolve().parent      # processed
BASE_DIR = CURRENT_DIR.parent                     # Gokul Rajaram

POSTS_JSON_PATH = CURRENT_DIR / "filtered_posts.json"
COMMENTS_FOLDER = CURRENT_DIR / "comments"

OUTPUT_JSON = CURRENT_DIR / "filtered_posts_with_comments.json"

print("📂 Current dir :", CURRENT_DIR)
print("📂 Base dir    :", BASE_DIR)
print("📄 Posts JSON  :", POSTS_JSON_PATH)

# --------------------------------------------------
# Step 1: Load posts JSON
# --------------------------------------------------
if not POSTS_JSON_PATH.exists():
    raise FileNotFoundError(f"❌ Missing file: {POSTS_JSON_PATH}")

with open(POSTS_JSON_PATH, "r", encoding="utf-8") as f:
    posts = json.load(f)

print(f"✅ Loaded {len(posts)} posts")

# --------------------------------------------------
# Step 2: Attach comments
# --------------------------------------------------
for post in posts:
    post_id = post.get("post_id")

    if not post_id:
        post["comments"] = []
        continue

    comments_file = COMMENTS_FOLDER / f"linkedin-{post_id}.csv"

    if comments_file.exists():
        df = pd.read_csv(comments_file)

        if "Comment" in df.columns:
            post["comments"] = (
                df["Comment"]
                .dropna()
                .astype(str)
                .tolist()
            )
        else:
            post["comments"] = []
    else:
        post["comments"] = []

# --------------------------------------------------
# Step 3: Save output
# --------------------------------------------------
with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
    json.dump(posts, f, indent=2, ensure_ascii=False)

print(f"✅ Saved posts with comments → {OUTPUT_JSON}")
