import pandas as pd
from pathlib import Path
import re
import json
import ast

# -------------------------------
# BASE PATH (current folder → comments)
# -------------------------------
CURRENT_DIR = Path(__file__).resolve().parent

BASE_DIR = CURRENT_DIR.parent.parent  # points to "data"

COMMENTS_FOLDER = CURRENT_DIR
POSTS_CSV = BASE_DIR / "raw" / "dataset_linkedin-profile-posts_2026-01-18_08-53-23-260.csv"

OUTPUT_JSON = BASE_DIR / "processed" / "filtered_posts.json"
OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)

print("✅ Script location:", CURRENT_DIR)
print("✅ Base dir:", BASE_DIR)

# -------------------------------
# Step 1: Collect post URNs from comment filenames
# -------------------------------
post_urns = set()

for f in COMMENTS_FOLDER.glob("*.csv"):
    match = re.search(r'linkedin-(\d+)', f.stem)
    if match:
        post_urns.add(match.group(1))

print(f"✅ Found {len(post_urns)} posts with comments")

# -------------------------------
# Step 2: Read posts CSV
# -------------------------------
df = pd.read_csv(POSTS_CSV)
print(f"✅ Total posts in main CSV: {len(df)}")

# -------------------------------
# Step 3: Extract post_id
# -------------------------------
def extract_post_id(row):
    for col in ["urn.activity_urn", "urn.ugcPost_urn", "full_urn"]:
        if col in row and pd.notna(row[col]):
            m = re.search(r'(\d+)', str(row[col]))
            if m:
                return m.group(1)
    return None

df["post_id"] = df.apply(extract_post_id, axis=1)

df = df[df["post_id"].isin(post_urns)].copy()
print(f"✅ Filtered posts count: {len(df)}")

# -------------------------------
# Step 4: Parse stringified dict columns
# -------------------------------
DICT_COLUMNS = [
    "urn", "posted_at", "author", "stats",
    "media", "document", "article"
]

def parse_dict(val):
    if isinstance(val, str) and val.strip().startswith("{"):
        try:
            return ast.literal_eval(val)
        except Exception:
            return None
    return val

for col in DICT_COLUMNS:
    if col in df.columns:
        df[col] = df[col].apply(parse_dict)

# -------------------------------
# Step 5: Flatten nested dictionaries
# -------------------------------
def flatten_record(record):
    flat = {}
    for k, v in record.items():
        if isinstance(v, dict):
            for sub_k, sub_v in v.items():
                flat[f"{k}.{sub_k}"] = sub_v
        else:
            flat[k] = v
    return flat

posts_list = [
    flatten_record(row)
    for row in df.to_dict(orient="records")
]

# -------------------------------
# Step 6: Save JSON
# -------------------------------
with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
    json.dump(posts_list, f, indent=2, ensure_ascii=False)

print(f"✅ Saved filtered posts JSON → {OUTPUT_JSON}")
